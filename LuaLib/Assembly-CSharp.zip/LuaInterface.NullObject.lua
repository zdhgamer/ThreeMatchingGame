---@class LuaInterface.NullObject : System.Object
local m = {}

LuaInterface.NullObject = m
return m
