---@class GameCamera : UnityEngine.MonoBehaviour
local m = {}

GameCamera = m
return m
