---@class DG.Tweening.DOTweenModuleUI._DOFade_c__AnonStorey4 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOFade_c__AnonStorey4 = m
return m
