---@class DG.Tweening.DOTweenModuleUI._DOPivotX_c__AnonStorey16 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOPivotX_c__AnonStorey16 = m
return m
