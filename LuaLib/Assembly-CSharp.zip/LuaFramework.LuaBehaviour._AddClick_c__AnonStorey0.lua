---@class LuaFramework.LuaBehaviour._AddClick_c__AnonStorey0 : System.Object
local m = {}

LuaFramework.LuaBehaviour._AddClick_c__AnonStorey0 = m
return m
