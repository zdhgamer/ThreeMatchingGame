---@class LuaFramework.Util : System.Object
---@field public DataPath string @static
---@field public NetAvailable boolean @static
---@field public IsWifi boolean @static
local m = {}

---@static
---@param o any
---@return number
function m.Int(o) end

---@static
---@param o any
---@return number
function m.Float(o) end

---@static
---@param o any
---@return number
function m.Long(o) end

---@overload fun(min:number, max:number): @static
---@static
---@param min number
---@param max number
---@return number
function m.Random(min, max) end

---@static
---@param uid string
---@return string
function m.Uid(uid) end

---@static
---@return number
function m.GetTime() end

---@overload fun(go:UnityEngine.Transform, subnode:string): @static
---@overload fun(go:UnityEngine.Component, subnode:string): @static
---@static
---@param go UnityEngine.GameObject
---@param subnode string
---@return UnityEngine.Component
function m.Get(go, subnode) end

---@overload fun(go:UnityEngine.Transform): @static
---@static
---@param go UnityEngine.GameObject
---@return UnityEngine.Component
function m.Add(go) end

---@overload fun(go:UnityEngine.Transform, subnode:string): @static
---@static
---@param go UnityEngine.GameObject
---@param subnode string
---@return UnityEngine.GameObject
function m.Child(go, subnode) end

---@overload fun(go:UnityEngine.Transform, subnode:string): @static
---@static
---@param go UnityEngine.GameObject
---@param subnode string
---@return UnityEngine.GameObject
function m.Peer(go, subnode) end

---@static
---@param source string
---@return string
function m.md5(source) end

---@static
---@param file string
---@return string
function m.md5file(file) end

---@static
---@param go UnityEngine.Transform
function m.ClearChild(go) end

---@static
function m.ClearMemory() end

---@static
---@return string
function m.GetRelativePath() end

---@static
---@param path string
---@return string
function m.GetFileText(path) end

---@static
---@return string
function m.AppContentPath() end

---@static
---@param str string
function m.Log(str) end

---@static
---@param str string
function m.LogWarning(str) end

---@static
---@param str string
function m.LogError(str) end

---@static
---@return number
function m.CheckRuntimeFile() end

---@overload fun(module:string, func:string): @static
---@static
---@param module string
---@param func string
---@param ... any|any[]
---@return any[]
function m.CallMethod(module, func, ...) end

---@static
---@return boolean
function m.CheckEnvironment() end

LuaFramework.Util = m
return m
