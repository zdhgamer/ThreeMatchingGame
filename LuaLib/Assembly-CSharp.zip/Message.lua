---@class Message : System.Object
---@field public Name string
---@field public Body any
---@field public Type string
local m = {}

---@virtual
---@return string
function m:ToString() end

Message = m
return m
