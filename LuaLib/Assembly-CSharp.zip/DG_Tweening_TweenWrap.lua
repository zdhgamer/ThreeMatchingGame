---@class DG_Tweening_TweenWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

DG_Tweening_TweenWrap = m
return m
