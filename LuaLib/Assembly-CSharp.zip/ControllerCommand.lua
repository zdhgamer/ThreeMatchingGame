---@class ControllerCommand : System.Object
local m = {}

---@virtual
---@param message IMessage
function m:Execute(message) end

ControllerCommand = m
return m
