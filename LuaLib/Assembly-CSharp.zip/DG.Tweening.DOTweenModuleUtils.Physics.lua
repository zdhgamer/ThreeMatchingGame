---@class DG.Tweening.DOTweenModuleUtils.Physics : System.Object
local m = {}

---@static
---@param options DG.Tweening.Plugins.Options.PathOptions
---@param t DG.Tweening.Tween
---@param newRot UnityEngine.Quaternion
---@param trans UnityEngine.Transform
function m.SetOrientationOnPath(options, t, newRot, trans) end

---@static
---@param target UnityEngine.Component
---@return boolean
function m.HasRigidbody2D(target) end

---@static
---@param target UnityEngine.Component
---@return boolean
function m.HasRigidbody(target) end

---@static
---@param target UnityEngine.MonoBehaviour
---@param tweenRigidbody boolean
---@param isLocal boolean
---@param path DG.Tweening.Plugins.Core.PathCore.Path
---@param duration number
---@param pathMode DG.Tweening.PathMode
---@return DG.Tweening.Core.TweenerCore_3_UnityEngine_Vector3_DG_Tweening_Plugins_Core_PathCore_Path_DG_Tweening_Plugins_Options_PathOptions_
function m.CreateDOTweenPathTween(target, tweenRigidbody, isLocal, path, duration, pathMode) end

DG.Tweening.DOTweenModuleUtils.Physics = m
return m
