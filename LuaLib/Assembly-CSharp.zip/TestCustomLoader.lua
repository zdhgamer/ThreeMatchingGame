---@class TestCustomLoader : LuaClient
local m = {}

TestCustomLoader = m
return m
