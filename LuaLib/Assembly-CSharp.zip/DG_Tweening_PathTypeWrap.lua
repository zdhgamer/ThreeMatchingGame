---@class DG_Tweening_PathTypeWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

DG_Tweening_PathTypeWrap = m
return m
