---@class DG.Tweening.DOTweenModuleUI._DOFade_c__AnonStorey0 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOFade_c__AnonStorey0 = m
return m
