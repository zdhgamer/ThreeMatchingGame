---@class DelegateFactory.UnityEngine_Events_UnityAction_Event : LuaInterface.LuaDelegate
local m = {}

function m:Call() end

function m:CallWithSelf() end

DelegateFactory.UnityEngine_Events_UnityAction_Event = m
return m
