---@class ICommand : table
local m = {}

---@abstract
---@param message IMessage
function m:Execute(message) end

ICommand = m
return m
