---@class LuaFramework.PoolInfo : System.Object
---@field public poolName string
---@field public prefab UnityEngine.GameObject
---@field public poolSize number
---@field public fixedSize boolean
local m = {}

LuaFramework.PoolInfo = m
return m
