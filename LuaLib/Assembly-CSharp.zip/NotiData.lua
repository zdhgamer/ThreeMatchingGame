---@class NotiData : System.Object
---@field public evName string
---@field public evParam any
local m = {}

NotiData = m
return m
