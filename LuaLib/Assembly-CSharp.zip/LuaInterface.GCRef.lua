---@class LuaInterface.GCRef : System.Object
---@field public reference number
---@field public name string
local m = {}

LuaInterface.GCRef = m
return m
