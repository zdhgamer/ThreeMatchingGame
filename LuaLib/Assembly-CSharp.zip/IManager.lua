---@class IManager : table
local m = {}

IManager = m
return m
