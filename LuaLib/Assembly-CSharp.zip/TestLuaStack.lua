---@class TestLuaStack : UnityEngine.MonoBehaviour
---@field public show LuaInterface.LuaFunction @static
---@field public testRay LuaInterface.LuaFunction @static
---@field public showStack LuaInterface.LuaFunction @static
---@field public test4 LuaInterface.LuaFunction @static
---@field public Instance TestLuaStack @static
---@field public go UnityEngine.GameObject
---@field public go2 UnityEngine.GameObject
---@field public text UnityEngine.TextAsset
local m = {}

TestLuaStack = m
return m
