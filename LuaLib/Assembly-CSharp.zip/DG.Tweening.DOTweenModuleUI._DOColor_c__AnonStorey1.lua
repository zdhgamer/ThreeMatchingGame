---@class DG.Tweening.DOTweenModuleUI._DOColor_c__AnonStorey1 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOColor_c__AnonStorey1 = m
return m
