---@class SocketClient : System.Object
---@field public loggedIn boolean @static
local m = {}

function m:OnRegister() end

function m:OnRemove() end

function m:Close() end

function m:SendConnect() end

---@param buffer LuaFramework.ByteBuffer
function m:SendMessage(buffer) end

SocketClient = m
return m
