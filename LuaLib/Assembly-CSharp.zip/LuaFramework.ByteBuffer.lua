---@class LuaFramework.ByteBuffer : System.Object
local m = {}

function m:Close() end

---@param v number
function m:WriteByte(v) end

---@param v number
function m:WriteInt(v) end

---@param v number
function m:WriteShort(v) end

---@param v number
function m:WriteLong(v) end

---@param v number
function m:WriteFloat(v) end

---@param v number
function m:WriteDouble(v) end

---@param v string
function m:WriteString(v) end

---@param v string
function m:WriteBytes(v) end

---@param strBuffer LuaInterface.LuaByteBuffer
function m:WriteBuffer(strBuffer) end

---@return number
function m:ReadByte() end

---@return number
function m:ReadInt() end

---@return number
function m:ReadShort() end

---@return number
function m:ReadLong() end

---@return number
function m:ReadFloat() end

---@return number
function m:ReadDouble() end

---@return string
function m:ReadString() end

---@return string
function m:ReadBytes() end

---@return LuaInterface.LuaByteBuffer
function m:ReadBuffer() end

---@return string
function m:ToBytes() end

function m:Flush() end

LuaFramework.ByteBuffer = m
return m
