---@class DG.Tweening.DOTweenModulePhysics2D._DOMoveX_c__AnonStorey1 : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics2D._DOMoveX_c__AnonStorey1 = m
return m
