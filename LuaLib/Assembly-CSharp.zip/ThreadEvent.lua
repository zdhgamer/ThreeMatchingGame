---@class ThreadEvent : System.Object
---@field public Key string
---@field public evParams any[]
local m = {}

ThreadEvent = m
return m
