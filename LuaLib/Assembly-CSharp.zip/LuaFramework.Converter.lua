---@class LuaFramework.Converter : System.Object
local m = {}

---@overload fun(value:number): @static
---@overload fun(value:number): @static
---@overload fun(value:number): @static
---@overload fun(value:number): @static
---@overload fun(value:number): @static
---@static
---@param value number
---@return number
function m.GetBigEndian(value) end

---@overload fun(value:number): @static
---@overload fun(value:number): @static
---@overload fun(value:number): @static
---@static
---@param value number
---@return number
function m.GetLittleEndian(value) end

LuaFramework.Converter = m
return m
