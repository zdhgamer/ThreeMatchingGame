---@class LuaFramework.ResourceManager : Manager
local m = {}

function m:Initialize() end

---@param abname string
---@param assetname string
---@return UnityEngine.Object
function m:LoadAsset(abname, assetname) end

---@param abName string
---@param assetNames string[]
---@param func LuaInterface.LuaFunction
function m:LoadPrefab(abName, assetNames, func) end

---@param abname string
---@return UnityEngine.AssetBundle
function m:LoadAssetBundle(abname) end

LuaFramework.ResourceManager = m
return m
