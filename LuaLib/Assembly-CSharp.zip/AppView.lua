---@class AppView : View
local m = {}

---@virtual
---@param message IMessage
function m:OnMessage(message) end

---@param data string
function m:UpdateMessage(data) end

---@param data string
function m:UpdateExtract(data) end

---@param data string
function m:UpdateDownload(data) end

---@param data string
function m:UpdateProgress(data) end

AppView = m
return m
