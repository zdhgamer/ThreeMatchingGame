---@class DG.Tweening.DOTweenModuleUI._DOShakeAnchorPos_c__AnonStorey1B : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOShakeAnchorPos_c__AnonStorey1B = m
return m
