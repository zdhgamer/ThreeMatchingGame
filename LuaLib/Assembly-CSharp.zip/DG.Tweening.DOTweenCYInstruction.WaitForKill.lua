---@class DG.Tweening.DOTweenCYInstruction.WaitForKill : UnityEngine.CustomYieldInstruction
---@field public keepWaiting boolean
local m = {}

DG.Tweening.DOTweenCYInstruction.WaitForKill = m
return m
