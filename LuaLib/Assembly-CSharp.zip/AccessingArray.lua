---@class AccessingArray : UnityEngine.MonoBehaviour
local m = {}

AccessingArray = m
return m
