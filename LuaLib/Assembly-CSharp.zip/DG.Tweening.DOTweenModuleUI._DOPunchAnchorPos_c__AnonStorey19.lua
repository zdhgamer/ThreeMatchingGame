---@class DG.Tweening.DOTweenModuleUI._DOPunchAnchorPos_c__AnonStorey19 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOPunchAnchorPos_c__AnonStorey19 = m
return m
