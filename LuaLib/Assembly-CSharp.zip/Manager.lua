---@class Manager : Base
local m = {}

Manager = m
return m
