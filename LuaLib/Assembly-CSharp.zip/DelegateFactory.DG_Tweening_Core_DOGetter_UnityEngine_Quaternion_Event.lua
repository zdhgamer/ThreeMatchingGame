---@class DelegateFactory.DG_Tweening_Core_DOGetter_UnityEngine_Quaternion_Event : LuaInterface.LuaDelegate
local m = {}

---@return UnityEngine.Quaternion
function m:Call() end

---@return UnityEngine.Quaternion
function m:CallWithSelf() end

DelegateFactory.DG_Tweening_Core_DOGetter_UnityEngine_Quaternion_Event = m
return m
