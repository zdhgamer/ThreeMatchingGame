---@class LuaFramework.ITimerBehaviour : table
local m = {}

---@abstract
function m:TimerUpdate() end

LuaFramework.ITimerBehaviour = m
return m
