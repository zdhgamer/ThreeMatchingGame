---@class DG.Tweening.DOTweenModuleUI._DOColor_c__AnonStorey3 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOColor_c__AnonStorey3 = m
return m
