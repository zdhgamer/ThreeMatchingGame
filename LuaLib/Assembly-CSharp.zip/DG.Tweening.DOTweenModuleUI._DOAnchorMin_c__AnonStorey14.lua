---@class DG.Tweening.DOTweenModuleUI._DOAnchorMin_c__AnonStorey14 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOAnchorMin_c__AnonStorey14 = m
return m
