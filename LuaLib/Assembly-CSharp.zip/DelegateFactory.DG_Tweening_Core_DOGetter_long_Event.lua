---@class DelegateFactory.DG_Tweening_Core_DOGetter_long_Event : LuaInterface.LuaDelegate
local m = {}

---@return number
function m:Call() end

---@return number
function m:CallWithSelf() end

DelegateFactory.DG_Tweening_Core_DOGetter_long_Event = m
return m
