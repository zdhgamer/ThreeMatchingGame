---@class DelegateFactory.EventTriggerListener_PointerEventDelegate_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 UnityEngine.GameObject
---@param param1 UnityEngine.EventSystems.PointerEventData
function m:Call(param0, param1) end

---@param param0 UnityEngine.GameObject
---@param param1 UnityEngine.EventSystems.PointerEventData
function m:CallWithSelf(param0, param1) end

DelegateFactory.EventTriggerListener_PointerEventDelegate_Event = m
return m
