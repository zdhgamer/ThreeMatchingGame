---@class LuaFramework.GameManager : Manager
local m = {}

function m:CheckExtractResource() end

function m:OnResourceInited() end

LuaFramework.GameManager = m
return m
