---@class UseList : LuaClient
local m = {}

UseList = m
return m
