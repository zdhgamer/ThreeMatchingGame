---@class DG.Tweening.DOTweenModuleUI._DOHorizontalNormalizedPos_c__AnonStorey1E : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOHorizontalNormalizedPos_c__AnonStorey1E = m
return m
