---@class DG.Tweening.DOTweenModulePhysics2D._DOMove_c__AnonStorey0 : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics2D._DOMove_c__AnonStorey0 = m
return m
