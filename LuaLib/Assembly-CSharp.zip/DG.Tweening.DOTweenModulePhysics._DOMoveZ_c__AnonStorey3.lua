---@class DG.Tweening.DOTweenModulePhysics._DOMoveZ_c__AnonStorey3 : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics._DOMoveZ_c__AnonStorey3 = m
return m
