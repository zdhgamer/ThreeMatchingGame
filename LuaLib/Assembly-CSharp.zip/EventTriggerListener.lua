---@class EventTriggerListener : UnityEngine.EventSystems.EventTrigger
local m = {}

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:add_onBeginDrag(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:remove_onBeginDrag(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:add_onDrag(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:remove_onDrag(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:add_onDrop(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:remove_onDrop(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:add_onEndDrag(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:remove_onEndDrag(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:add_onInitializePotentialDrag(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:remove_onInitializePotentialDrag(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:add_onPointerClick(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:remove_onPointerClick(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:add_onPointerDown(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:remove_onPointerDown(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:add_onPointerEnter(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:remove_onPointerEnter(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:add_onPointerExit(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:remove_onPointerExit(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:add_onPointerUp(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:remove_onPointerUp(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:add_onScroll(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.PointerEventData)
function m:remove_onScroll(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.BaseEventData)
function m:add_onCancel(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.BaseEventData)
function m:remove_onCancel(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.BaseEventData)
function m:add_onDeselect(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.BaseEventData)
function m:remove_onDeselect(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.BaseEventData)
function m:add_onSelect(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.BaseEventData)
function m:remove_onSelect(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.BaseEventData)
function m:add_onSubmit(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.BaseEventData)
function m:remove_onSubmit(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.BaseEventData)
function m:add_onUpdateSelected(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.BaseEventData)
function m:remove_onUpdateSelected(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.AxisEventData)
function m:add_onMove(value) end

---@param value fun(go:UnityEngine.GameObject, eventData:UnityEngine.EventSystems.AxisEventData)
function m:remove_onMove(value) end

---@static
---@param go UnityEngine.GameObject
---@return EventTriggerListener
function m.GetListener(go) end

---@param table LuaInterface.LuaTable
function m:SetLuaTable(table) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnBeginDrag(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnDrag(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnDrop(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnEndDrag(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnInitializePotentialDrag(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerClick(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerDown(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerEnter(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerExit(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnPointerUp(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:OnScroll(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.BaseEventData
function m:OnCancel(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.BaseEventData
function m:OnDeselect(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.BaseEventData
function m:OnSelect(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.BaseEventData
function m:OnSubmit(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.BaseEventData
function m:OnUpdateSelected(eventData) end

---@virtual
---@param eventData UnityEngine.EventSystems.AxisEventData
function m:OnMove(eventData) end

EventTriggerListener = m
return m
