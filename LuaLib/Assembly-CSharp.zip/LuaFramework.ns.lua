---@class LuaFramework
LuaFramework = {}