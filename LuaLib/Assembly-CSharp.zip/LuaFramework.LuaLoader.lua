---@class LuaFramework.LuaLoader : LuaInterface.LuaFileUtils
local m = {}

---@param bundleName string
function m:AddBundle(bundleName) end

---@virtual
---@param fileName string
---@return string
function m:ReadFile(fileName) end

LuaFramework.LuaLoader = m
return m
