---@class DelegateFactory.DG_Tweening_Core_DOGetter_UnityEngine_Vector3_Event : LuaInterface.LuaDelegate
local m = {}

---@return UnityEngine.Vector3
function m:Call() end

---@return UnityEngine.Vector3
function m:CallWithSelf() end

DelegateFactory.DG_Tweening_Core_DOGetter_UnityEngine_Vector3_Event = m
return m
