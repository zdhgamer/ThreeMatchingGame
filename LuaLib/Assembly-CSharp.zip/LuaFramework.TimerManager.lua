---@class LuaFramework.TimerManager : Manager
---@field public Interval number
local m = {}

---@param value number
function m:StartTimer(value) end

function m:StopTimer() end

---@param info LuaFramework.TimerInfo
function m:AddTimerEvent(info) end

---@param info LuaFramework.TimerInfo
function m:RemoveTimerEvent(info) end

---@param info LuaFramework.TimerInfo
function m:StopTimerEvent(info) end

---@param info LuaFramework.TimerInfo
function m:ResumeTimerEvent(info) end

LuaFramework.TimerManager = m
return m
