---@class DG.Tweening.DOTweenModulePhysics._DOPath_c__AnonStorey9 : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics._DOPath_c__AnonStorey9 = m
return m
