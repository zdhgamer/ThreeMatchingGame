---@class DG.Tweening.DOTweenModuleUI._DOAnchorPos3D_c__AnonStoreyF : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOAnchorPos3D_c__AnonStoreyF = m
return m
