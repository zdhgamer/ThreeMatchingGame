---@class LuaInterface.UseDefinedAttribute : System.Attribute
local m = {}

LuaInterface.UseDefinedAttribute = m
return m
