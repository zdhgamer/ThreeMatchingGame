---@class DG.Tweening.DOTweenModulePhysics._DOLocalPath_c__AnonStorey8 : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics._DOLocalPath_c__AnonStorey8 = m
return m
