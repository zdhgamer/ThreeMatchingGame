---@class LuaFramework.Protocal : System.Object
---@field public Connect number @static
---@field public Exception number @static
---@field public Disconnect number @static
local m = {}

LuaFramework.Protocal = m
return m
