---@class DG.Tweening.DOTweenModuleUI._DOAnchorPos3DZ_c__AnonStorey12 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOAnchorPos3DZ_c__AnonStorey12 = m
return m
