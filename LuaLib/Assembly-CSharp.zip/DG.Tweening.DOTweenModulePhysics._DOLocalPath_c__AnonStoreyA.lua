---@class DG.Tweening.DOTweenModulePhysics._DOLocalPath_c__AnonStoreyA : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics._DOLocalPath_c__AnonStoreyA = m
return m
