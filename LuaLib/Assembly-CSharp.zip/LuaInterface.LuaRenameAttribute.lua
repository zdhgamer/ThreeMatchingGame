---@class LuaInterface.LuaRenameAttribute : System.Attribute
---@field public Name string
local m = {}

LuaInterface.LuaRenameAttribute = m
return m
