---@class LuaInterface.NoToLuaAttribute : System.Attribute
local m = {}

LuaInterface.NoToLuaAttribute = m
return m
