---@class LuaFramework.ThreadManager.ThreadSyncEvent : System.MulticastDelegate
local m = {}

---@virtual
---@param data NotiData
function m:Invoke(data) end

---@virtual
---@param data NotiData
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(data, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

LuaFramework.ThreadManager.ThreadSyncEvent = m
return m
