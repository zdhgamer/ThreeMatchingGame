---@class LuaBinder : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Bind(L) end

LuaBinder = m
return m
