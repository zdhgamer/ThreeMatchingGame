---@class LuaFramework_ThreadManagerWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaFramework_ThreadManagerWrap = m
return m
