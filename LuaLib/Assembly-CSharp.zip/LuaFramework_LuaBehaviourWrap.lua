---@class LuaFramework_LuaBehaviourWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaFramework_LuaBehaviourWrap = m
return m
