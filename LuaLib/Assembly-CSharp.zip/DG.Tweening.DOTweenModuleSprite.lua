---@class DG.Tweening.DOTweenModuleSprite : System.Object
local m = {}

---@static
---@param target UnityEngine.SpriteRenderer
---@param endValue UnityEngine.Color
---@param duration number
---@return DG.Tweening.Tweener
function m.DOColor(target, endValue, duration) end

---@static
---@param target UnityEngine.SpriteRenderer
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOFade(target, endValue, duration) end

---@static
---@param target UnityEngine.SpriteRenderer
---@param gradient UnityEngine.Gradient
---@param duration number
---@return DG.Tweening.Sequence
function m.DOGradientColor(target, gradient, duration) end

---@static
---@param target UnityEngine.SpriteRenderer
---@param endValue UnityEngine.Color
---@param duration number
---@return DG.Tweening.Tweener
function m.DOBlendableColor(target, endValue, duration) end

DG.Tweening.DOTweenModuleSprite = m
return m
