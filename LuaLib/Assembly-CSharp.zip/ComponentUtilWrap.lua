---@class ComponentUtilWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

ComponentUtilWrap = m
return m
