---@class DelegateFactory.DG_Tweening_Core_DOGetter_UnityEngine_Vector2_Event : LuaInterface.LuaDelegate
local m = {}

---@return UnityEngine.Vector2
function m:Call() end

---@return UnityEngine.Vector2
function m:CallWithSelf() end

DelegateFactory.DG_Tweening_Core_DOGetter_UnityEngine_Vector2_Event = m
return m
