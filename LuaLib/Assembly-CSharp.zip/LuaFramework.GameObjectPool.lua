---@class LuaFramework.GameObjectPool : System.Object
local m = {}

---@return UnityEngine.GameObject
function m:NextAvailableObject() end

---@param pool string
---@param po UnityEngine.GameObject
function m:ReturnObjectToPool(pool, po) end

LuaFramework.GameObjectPool = m
return m
