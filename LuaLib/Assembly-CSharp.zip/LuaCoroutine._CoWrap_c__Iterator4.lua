---@class LuaCoroutine._CoWrap_c__Iterator4 : System.Object
local m = {}

---@virtual
---@return boolean
function m:MoveNext() end

---@virtual
function m:Dispose() end

---@virtual
function m:Reset() end

LuaCoroutine._CoWrap_c__Iterator4 = m
return m
