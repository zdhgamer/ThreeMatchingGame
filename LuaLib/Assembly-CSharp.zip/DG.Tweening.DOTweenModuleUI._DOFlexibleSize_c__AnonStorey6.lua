---@class DG.Tweening.DOTweenModuleUI._DOFlexibleSize_c__AnonStorey6 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOFlexibleSize_c__AnonStorey6 = m
return m
