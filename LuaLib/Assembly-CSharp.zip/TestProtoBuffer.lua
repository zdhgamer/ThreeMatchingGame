---@class TestProtoBuffer : LuaClient
local m = {}

TestProtoBuffer = m
return m
