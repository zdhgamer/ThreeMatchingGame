---@class DG.Tweening.DOTweenModuleUI._DOFade_c__AnonStorey2 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOFade_c__AnonStorey2 = m
return m
