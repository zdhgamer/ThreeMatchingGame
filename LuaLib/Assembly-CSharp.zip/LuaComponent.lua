---@class LuaComponent : UnityEngine.MonoBehaviour
---@field public ComponentName string
local m = {}

---@static
---@param go UnityEngine.GameObject
---@param luaTable LuaInterface.LuaTable
---@return LuaComponent
function m.AddLuaComponent(go, luaTable) end

---@param luaTable LuaInterface.LuaTable
function m:SetLuaTable(luaTable) end

function m:CallAwake() end

LuaComponent = m
return m
