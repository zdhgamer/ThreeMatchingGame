---@class DG_Tweening_RotateModeWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

DG_Tweening_RotateModeWrap = m
return m
