---@class View : Base
local m = {}

---@virtual
---@param message IMessage
function m:OnMessage(message) end

View = m
return m
