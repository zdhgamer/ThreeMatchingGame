---@class DG.Tweening.DOTweenModuleUI._DOJumpAnchorPos_c__AnonStorey1C : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOJumpAnchorPos_c__AnonStorey1C = m
return m
