---@class UnityEngine_TrailRendererWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_TrailRendererWrap = m
return m
