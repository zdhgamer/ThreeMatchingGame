---@class TestExport.Space : System.Enum
---@field public World TestExport.Space @static
---@field public value__ number
local m = {}

TestExport.Space = m
return m
