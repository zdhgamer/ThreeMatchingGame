---@class UnityEngine_EventSystems_EventTriggerWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_EventSystems_EventTriggerWrap = m
return m
