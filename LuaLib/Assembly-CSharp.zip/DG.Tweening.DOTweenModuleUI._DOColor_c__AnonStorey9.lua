---@class DG.Tweening.DOTweenModuleUI._DOColor_c__AnonStorey9 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOColor_c__AnonStorey9 = m
return m
