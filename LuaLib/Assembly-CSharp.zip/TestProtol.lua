---@class TestProtol : System.Object
---@field public data string @static
local m = {}

TestProtol = m
return m
