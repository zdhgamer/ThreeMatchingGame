---@class LuaFramework.PanelManager : Manager
local m = {}

---@overload fun(name:string)
---@param name string
---@param func LuaInterface.LuaFunction
function m:CreatePanel(name, func) end

---@param name string
function m:ClosePanel(name) end

LuaFramework.PanelManager = m
return m
