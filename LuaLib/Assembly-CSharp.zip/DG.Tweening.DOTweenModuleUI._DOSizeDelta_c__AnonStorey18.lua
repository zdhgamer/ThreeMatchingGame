---@class DG.Tweening.DOTweenModuleUI._DOSizeDelta_c__AnonStorey18 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOSizeDelta_c__AnonStorey18 = m
return m
