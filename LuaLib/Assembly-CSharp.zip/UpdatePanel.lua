---@class UpdatePanel : UnityEngine.MonoBehaviour
local m = {}

function m:SetStartExtractResource() end

function m:SetStartUpdateResource() end

---@param progress number
function m:UpdateExtractProgress(progress) end

---@param progress number
function m:UpdateDownloadProgress(progress) end

---@param value string
function m:UpdateDownloadKbs(value) end

UpdatePanel = m
return m
