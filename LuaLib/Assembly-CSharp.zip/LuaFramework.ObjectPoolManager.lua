---@class LuaFramework.ObjectPoolManager : Manager
local m = {}

---@overload fun(actionOnGet:fun(arg0:any), actionOnRelease:fun(arg0:any)):
---@param poolName string
---@param initSize number
---@param maxSize number
---@param prefab UnityEngine.GameObject
---@return LuaFramework.GameObjectPool
function m:CreatePool(poolName, initSize, maxSize, prefab) end

---@overload fun():
---@param poolName string
---@return LuaFramework.GameObjectPool
function m:GetPool(poolName) end

---@overload fun():
---@param poolName string
---@return UnityEngine.GameObject
function m:Get(poolName) end

---@overload fun(obj:any)
---@param poolName string
---@param go UnityEngine.GameObject
function m:Release(poolName, go) end

LuaFramework.ObjectPoolManager = m
return m
