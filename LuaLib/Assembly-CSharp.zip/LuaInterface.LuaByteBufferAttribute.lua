---@class LuaInterface.LuaByteBufferAttribute : System.Attribute
local m = {}

LuaInterface.LuaByteBufferAttribute = m
return m
