---@class LuaInterface.LuaGCOptions : System.Enum
---@field public LUA_GCSTOP LuaInterface.LuaGCOptions @static
---@field public LUA_GCRESTART LuaInterface.LuaGCOptions @static
---@field public LUA_GCCOLLECT LuaInterface.LuaGCOptions @static
---@field public LUA_GCCOUNT LuaInterface.LuaGCOptions @static
---@field public LUA_GCCOUNTB LuaInterface.LuaGCOptions @static
---@field public LUA_GCSTEP LuaInterface.LuaGCOptions @static
---@field public LUA_GCSETPAUSE LuaInterface.LuaGCOptions @static
---@field public LUA_GCSETSTEPMUL LuaInterface.LuaGCOptions @static
---@field public value__ number
local m = {}

LuaInterface.LuaGCOptions = m
return m
