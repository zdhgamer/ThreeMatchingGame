---@class LuaInterface.RaycastBits : System.Object
---@field public Collider number @static
---@field public Normal number @static
---@field public Point number @static
---@field public Rigidbody number @static
---@field public Transform number @static
---@field public ALL number @static
local m = {}

LuaInterface.RaycastBits = m
return m
