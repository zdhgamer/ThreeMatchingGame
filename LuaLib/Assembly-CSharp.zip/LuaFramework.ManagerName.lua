---@class LuaFramework.ManagerName : System.Object
---@field public Lua string @static
---@field public Game string @static
---@field public Timer string @static
---@field public Sound string @static
---@field public Panel string @static
---@field public Network string @static
---@field public Resource string @static
---@field public Thread string @static
---@field public ObjectPool string @static
local m = {}

LuaFramework.ManagerName = m
return m
