---@class DG.Tweening.DOTweenModuleUI._DOAnchorPos3DY_c__AnonStorey11 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOAnchorPos3DY_c__AnonStorey11 = m
return m
