---@class DG.Tweening.DOTweenCYInstruction.WaitForPosition : UnityEngine.CustomYieldInstruction
---@field public keepWaiting boolean
local m = {}

DG.Tweening.DOTweenCYInstruction.WaitForPosition = m
return m
