---@class LuaFramework_LuaHelperWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaFramework_LuaHelperWrap = m
return m
