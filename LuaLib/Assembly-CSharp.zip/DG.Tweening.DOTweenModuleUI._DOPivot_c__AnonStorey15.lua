---@class DG.Tweening.DOTweenModuleUI._DOPivot_c__AnonStorey15 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOPivot_c__AnonStorey15 = m
return m
