---@class DG.Tweening.DOTweenModuleUI._DOAnchorPosX_c__AnonStoreyD : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOAnchorPosX_c__AnonStoreyD = m
return m
