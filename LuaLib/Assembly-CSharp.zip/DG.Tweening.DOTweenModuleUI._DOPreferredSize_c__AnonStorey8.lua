---@class DG.Tweening.DOTweenModuleUI._DOPreferredSize_c__AnonStorey8 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOPreferredSize_c__AnonStorey8 = m
return m
