---@class DG.Tweening.DOTweenModuleUI._DOShakeAnchorPos_c__AnonStorey1A : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOShakeAnchorPos_c__AnonStorey1A = m
return m
