---@class _PrivateImplementationDetails_ : System.Object
local m = {}

_PrivateImplementationDetails_ = m
return m
