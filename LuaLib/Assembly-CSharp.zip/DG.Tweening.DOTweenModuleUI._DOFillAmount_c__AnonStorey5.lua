---@class DG.Tweening.DOTweenModuleUI._DOFillAmount_c__AnonStorey5 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOFillAmount_c__AnonStorey5 = m
return m
