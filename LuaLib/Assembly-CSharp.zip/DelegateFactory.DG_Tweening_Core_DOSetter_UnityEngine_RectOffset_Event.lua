---@class DelegateFactory.DG_Tweening_Core_DOSetter_UnityEngine_RectOffset_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 UnityEngine.RectOffset
function m:Call(param0) end

---@param param0 UnityEngine.RectOffset
function m:CallWithSelf(param0) end

DelegateFactory.DG_Tweening_Core_DOSetter_UnityEngine_RectOffset_Event = m
return m
