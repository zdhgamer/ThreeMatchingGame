---@class LuaInterface_InjectTypeWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaInterface_InjectTypeWrap = m
return m
