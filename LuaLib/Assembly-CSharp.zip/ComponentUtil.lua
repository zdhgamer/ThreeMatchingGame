---@class ComponentUtil : System.Object
local m = {}

---@overload fun(go:UnityEngine.GameObject): @static
---@static
---@param go UnityEngine.GameObject
---@param componentName string
---@return LuaComponent[]
function m.GetLuaComponents(go, componentName) end

---@overload fun(go:UnityEngine.GameObject, componentName:string): @static
---@static
---@param go UnityEngine.GameObject
---@return LuaComponent[]
function m.GetLuaComponentsInChildren(go) end

---@overload fun(go:UnityEngine.GameObject, componentName:string): @static
---@static
---@param go UnityEngine.GameObject
---@return LuaComponent[]
function m.GetLuaComponentsInParen(go) end

ComponentUtil = m
return m
