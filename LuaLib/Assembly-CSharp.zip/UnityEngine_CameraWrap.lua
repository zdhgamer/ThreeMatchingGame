---@class UnityEngine_CameraWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_CameraWrap = m
return m
