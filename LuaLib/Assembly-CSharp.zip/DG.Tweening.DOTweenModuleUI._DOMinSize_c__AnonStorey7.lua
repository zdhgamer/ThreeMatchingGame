---@class DG.Tweening.DOTweenModuleUI._DOMinSize_c__AnonStorey7 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOMinSize_c__AnonStorey7 = m
return m
