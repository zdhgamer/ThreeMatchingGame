---@class LuaFramework.ThreadManager : Manager
local m = {}

---@param ev ThreadEvent
---@param func fun(obj:NotiData)
function m:AddEvent(ev, func) end

LuaFramework.ThreadManager = m
return m
