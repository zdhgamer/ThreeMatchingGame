---@class LuaFramework.GameManager._OnUpdateResource_c__Iterator1 : System.Object
local m = {}

---@virtual
---@return boolean
function m:MoveNext() end

---@virtual
function m:Dispose() end

---@virtual
function m:Reset() end

LuaFramework.GameManager._OnUpdateResource_c__Iterator1 = m
return m
