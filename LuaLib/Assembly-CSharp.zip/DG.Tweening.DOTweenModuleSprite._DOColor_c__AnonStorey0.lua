---@class DG.Tweening.DOTweenModuleSprite._DOColor_c__AnonStorey0 : System.Object
local m = {}

DG.Tweening.DOTweenModuleSprite._DOColor_c__AnonStorey0 = m
return m
