---@class DG.Tweening.DOTweenModuleUI._DOValue_c__AnonStorey20 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOValue_c__AnonStorey20 = m
return m
