---@class LuaFramework.LuaHelper : System.Object
local m = {}

---@static
---@param classname string
---@return System.Type
function m.GetType(classname) end

---@static
---@return LuaFramework.PanelManager
function m.GetPanelManager() end

---@static
---@return LuaFramework.ResourceManager
function m.GetResManager() end

---@static
---@return LuaFramework.NetworkManager
function m.GetNetManager() end

---@static
---@return LuaFramework.SoundManager
function m.GetSoundManager() end

---@static
---@param data LuaInterface.LuaByteBuffer
---@param func LuaInterface.LuaFunction
function m.OnCallLuaFunc(data, func) end

---@static
---@param data string
---@param func LuaInterface.LuaFunction
function m.OnJsonCallFunc(data, func) end

LuaFramework.LuaHelper = m
return m
