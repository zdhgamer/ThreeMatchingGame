---@class LuaFramework_NetworkManagerWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaFramework_NetworkManagerWrap = m
return m
