---@class EventTriggerListener.PointerEventDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param go UnityEngine.GameObject
---@param eventData UnityEngine.EventSystems.PointerEventData
function m:Invoke(go, eventData) end

---@virtual
---@param go UnityEngine.GameObject
---@param eventData UnityEngine.EventSystems.PointerEventData
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(go, eventData, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

EventTriggerListener.PointerEventDelegate = m
return m
