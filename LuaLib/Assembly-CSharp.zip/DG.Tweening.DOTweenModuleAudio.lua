---@class DG.Tweening.DOTweenModuleAudio : System.Object
local m = {}

---@static
---@param target UnityEngine.AudioSource
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOFade(target, endValue, duration) end

---@static
---@param target UnityEngine.AudioSource
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOPitch(target, endValue, duration) end

---@static
---@param target UnityEngine.Audio.AudioMixer
---@param floatName string
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOSetFloat(target, floatName, endValue, duration) end

---@overload fun(target:UnityEngine.Audio.AudioMixer): @static
---@static
---@param target UnityEngine.Audio.AudioMixer
---@param withCallbacks boolean
---@return number
function m.DOComplete(target, withCallbacks) end

---@overload fun(target:UnityEngine.Audio.AudioMixer): @static
---@static
---@param target UnityEngine.Audio.AudioMixer
---@param complete boolean
---@return number
function m.DOKill(target, complete) end

---@static
---@param target UnityEngine.Audio.AudioMixer
---@return number
function m.DOFlip(target) end

---@overload fun(target:UnityEngine.Audio.AudioMixer, to:number): @static
---@static
---@param target UnityEngine.Audio.AudioMixer
---@param to number
---@param andPlay boolean
---@return number
function m.DOGoto(target, to, andPlay) end

---@static
---@param target UnityEngine.Audio.AudioMixer
---@return number
function m.DOPause(target) end

---@static
---@param target UnityEngine.Audio.AudioMixer
---@return number
function m.DOPlay(target) end

---@static
---@param target UnityEngine.Audio.AudioMixer
---@return number
function m.DOPlayBackwards(target) end

---@static
---@param target UnityEngine.Audio.AudioMixer
---@return number
function m.DOPlayForward(target) end

---@static
---@param target UnityEngine.Audio.AudioMixer
---@return number
function m.DORestart(target) end

---@static
---@param target UnityEngine.Audio.AudioMixer
---@return number
function m.DORewind(target) end

---@static
---@param target UnityEngine.Audio.AudioMixer
---@return number
function m.DOSmoothRewind(target) end

---@static
---@param target UnityEngine.Audio.AudioMixer
---@return number
function m.DOTogglePause(target) end

DG.Tweening.DOTweenModuleAudio = m
return m
