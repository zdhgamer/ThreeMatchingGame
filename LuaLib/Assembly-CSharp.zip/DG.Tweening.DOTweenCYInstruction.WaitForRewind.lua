---@class DG.Tweening.DOTweenCYInstruction.WaitForRewind : UnityEngine.CustomYieldInstruction
---@field public keepWaiting boolean
local m = {}

DG.Tweening.DOTweenCYInstruction.WaitForRewind = m
return m
