---@class TestGameObject : UnityEngine.MonoBehaviour
local m = {}

TestGameObject = m
return m
