---@class QAQ : UnityEngine.MonoBehaviour
local m = {}

function m:OnClick() end

QAQ = m
return m
