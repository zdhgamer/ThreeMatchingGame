---@class DG.Tweening.DOTweenModuleUI._DOPivotY_c__AnonStorey17 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOPivotY_c__AnonStorey17 = m
return m
