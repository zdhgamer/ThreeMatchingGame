---@class System_Collections_IEnumeratorWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

System_Collections_IEnumeratorWrap = m
return m
