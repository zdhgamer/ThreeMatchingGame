---@class NotiConst : System.Object
---@field public START_UP string @static
---@field public DISPATCH_MESSAGE string @static
---@field public UPDATE_EXTRACT_PROGRESS string @static
---@field public START_EXTRACT string @static
---@field public START_DOWNLOAD string @static
---@field public UPDATE_DOWNLOAD string @static
---@field public UPDATE_DOWNLOAD_PROGRESS string @static
---@field public UPDATE_DOWNLOAD_KBPERS string @static
---@field public UPDATE_DOWNLOAD_FINISH string @static
local m = {}

NotiConst = m
return m
