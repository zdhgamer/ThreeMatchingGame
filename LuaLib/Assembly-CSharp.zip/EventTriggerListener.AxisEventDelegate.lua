---@class EventTriggerListener.AxisEventDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param go UnityEngine.GameObject
---@param eventData UnityEngine.EventSystems.AxisEventData
function m:Invoke(go, eventData) end

---@virtual
---@param go UnityEngine.GameObject
---@param eventData UnityEngine.EventSystems.AxisEventData
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(go, eventData, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

EventTriggerListener.AxisEventDelegate = m
return m
