---@class DG.Tweening.DOTweenModuleUI._DOBlendableColor_c__AnonStorey24 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOBlendableColor_c__AnonStorey24 = m
return m
