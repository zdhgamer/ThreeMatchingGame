---@class LuaInterface.TouchBits : System.Object
---@field public DeltaPosition number @static
---@field public Position number @static
---@field public RawPosition number @static
---@field public ALL number @static
local m = {}

LuaInterface.TouchBits = m
return m
