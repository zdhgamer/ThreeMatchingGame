---@class LuaFramework.TimerInfo : System.Object
---@field public tick number
---@field public stop boolean
---@field public delete boolean
---@field public target UnityEngine.Object
---@field public className string
local m = {}

LuaFramework.TimerInfo = m
return m
