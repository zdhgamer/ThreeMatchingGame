---@class DG.Tweening.DOTweenModulePhysics._DOLookAt_c__AnonStorey5 : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics._DOLookAt_c__AnonStorey5 = m
return m
