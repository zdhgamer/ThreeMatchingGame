---@class IController : table
local m = {}

---@abstract
---@param messageName string
---@param commandType System.Type
function m:RegisterCommand(messageName, commandType) end

---@abstract
---@param view IView
---@param commandNames string[]
function m:RegisterViewCommand(view, commandNames) end

---@abstract
---@param message IMessage
function m:ExecuteCommand(message) end

---@abstract
---@param messageName string
function m:RemoveCommand(messageName) end

---@abstract
---@param view IView
---@param commandNames string[]
function m:RemoveViewCommand(view, commandNames) end

---@abstract
---@param messageName string
---@return boolean
function m:HasCommand(messageName) end

IController = m
return m
