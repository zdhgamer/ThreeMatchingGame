---@class DG.Tweening.DOTweenModulePhysics._DOPath_c__AnonStorey7 : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics._DOPath_c__AnonStorey7 = m
return m
