---@class DG.Tweening.DOTweenModuleAudio._DOSetFloat_c__AnonStorey2 : System.Object
local m = {}

DG.Tweening.DOTweenModuleAudio._DOSetFloat_c__AnonStorey2 = m
return m
