---@class LuaFramework.TestObjectClass : System.Object
---@field public name string
---@field public value1 number
---@field public value2 number
local m = {}

---@return string
function m:ToString() end

LuaFramework.TestObjectClass = m
return m
