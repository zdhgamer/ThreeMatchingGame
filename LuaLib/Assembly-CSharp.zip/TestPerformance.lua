---@class TestPerformance : UnityEngine.MonoBehaviour
local m = {}

TestPerformance = m
return m
