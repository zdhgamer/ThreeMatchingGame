---@class DG.Tweening.DOTweenModuleUI._DOBlendableColor_c__AnonStorey25 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOBlendableColor_c__AnonStorey25 = m
return m
