---@class LuaFramework.Main : UnityEngine.MonoBehaviour
local m = {}

LuaFramework.Main = m
return m
