---@class DG.Tweening.DOTweenModuleUI._DOAnchorPos_c__AnonStoreyC : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOAnchorPos_c__AnonStoreyC = m
return m
