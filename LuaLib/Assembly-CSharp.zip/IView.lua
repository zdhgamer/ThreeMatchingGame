---@class IView : table
local m = {}

---@abstract
---@param message IMessage
function m:OnMessage(message) end

IView = m
return m
