---@class DG.Tweening.DOTweenModulePhysics._DORotate_c__AnonStorey4 : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics._DORotate_c__AnonStorey4 = m
return m
