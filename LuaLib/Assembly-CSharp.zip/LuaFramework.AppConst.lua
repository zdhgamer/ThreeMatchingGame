---@class LuaFramework.AppConst : System.Object
---@field public DebugMode boolean @static
---@field public UpdateMode boolean @static
---@field public LuaByteMode boolean @static
---@field public LuaBundleMode boolean @static
---@field public TimerInterval number @static
---@field public GameFrameRate number @static
---@field public AppName string @static
---@field public LuaTempDir string @static
---@field public AppPrefix string @static
---@field public ExtName string @static
---@field public AssetDir string @static
---@field public WebUrl string @static
---@field public UserId string @static
---@field public SocketPort number @static
---@field public SocketAddress string @static
---@field public FrameworkRoot string @static
local m = {}

LuaFramework.AppConst = m
return m
