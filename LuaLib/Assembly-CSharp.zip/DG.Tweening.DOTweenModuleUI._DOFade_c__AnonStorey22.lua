---@class DG.Tweening.DOTweenModuleUI._DOFade_c__AnonStorey22 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOFade_c__AnonStorey22 = m
return m
