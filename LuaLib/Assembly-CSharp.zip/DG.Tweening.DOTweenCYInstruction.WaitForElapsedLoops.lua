---@class DG.Tweening.DOTweenCYInstruction.WaitForElapsedLoops : UnityEngine.CustomYieldInstruction
---@field public keepWaiting boolean
local m = {}

DG.Tweening.DOTweenCYInstruction.WaitForElapsedLoops = m
return m
