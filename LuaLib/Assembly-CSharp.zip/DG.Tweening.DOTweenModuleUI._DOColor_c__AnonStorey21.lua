---@class DG.Tweening.DOTweenModuleUI._DOColor_c__AnonStorey21 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOColor_c__AnonStorey21 = m
return m
