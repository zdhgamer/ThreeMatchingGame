---@class DG.Tweening.DOTweenModuleUI._DONormalizedPos_c__AnonStorey1D : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DONormalizedPos_c__AnonStorey1D = m
return m
