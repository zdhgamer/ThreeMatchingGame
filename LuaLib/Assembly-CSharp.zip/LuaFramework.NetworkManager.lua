---@class LuaFramework.NetworkManager : Manager
local m = {}

function m:OnInit() end

function m:Unload() end

---@overload fun(func:string):
---@param func string
---@param ... any|any[]
---@return any[]
function m:CallMethod(func, ...) end

---@static
---@param _event number
---@param data LuaFramework.ByteBuffer
function m.AddEvent(_event, data) end

function m:SendConnect() end

---@param buffer LuaFramework.ByteBuffer
function m:SendMessage(buffer) end

LuaFramework.NetworkManager = m
return m
