---@class DG.Tweening.DOTweenModuleUI._DOBlendableColor_c__AnonStorey26 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOBlendableColor_c__AnonStorey26 = m
return m
