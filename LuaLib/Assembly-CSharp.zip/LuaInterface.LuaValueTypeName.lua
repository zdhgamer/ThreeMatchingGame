---@class LuaInterface.LuaValueTypeName : System.Object
---@field public names string[] @static
local m = {}

---@static
---@param type number
---@return string
function m.Get(type) end

LuaInterface.LuaValueTypeName = m
return m
