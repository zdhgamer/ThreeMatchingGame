---@class DG.Tweening.DOTweenModulePhysics._DOJump_c__AnonStorey6 : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics._DOJump_c__AnonStorey6 = m
return m
