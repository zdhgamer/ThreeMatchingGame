---@class DG.Tweening.DOTweenModuleUI._DOScale_c__AnonStoreyB : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOScale_c__AnonStoreyB = m
return m
