---@class DG.Tweening.DOTweenModulePhysics2D._DORotate_c__AnonStorey3 : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics2D._DORotate_c__AnonStorey3 = m
return m
