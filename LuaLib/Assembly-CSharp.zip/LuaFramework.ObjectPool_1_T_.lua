---@class LuaFramework.ObjectPool_1_T_ : System.Object
---@field public countAll number
---@field public countActive number
---@field public countInactive number
local m = {}

---@return any
function m:Get() end

---@param element any
function m:Release(element) end

LuaFramework.ObjectPool_1_T_ = m
return m
