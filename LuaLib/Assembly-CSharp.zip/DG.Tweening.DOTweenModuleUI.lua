---@class DG.Tweening.DOTweenModuleUI : System.Object
local m = {}

---@overload fun(target:UnityEngine.UI.Graphic, endValue:number, duration:number): @static
---@overload fun(target:UnityEngine.UI.Image, endValue:number, duration:number): @static
---@overload fun(target:UnityEngine.UI.Outline, endValue:number, duration:number): @static
---@overload fun(target:UnityEngine.UI.Text, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.CanvasGroup
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOFade(target, endValue, duration) end

---@overload fun(target:UnityEngine.UI.Image, endValue:UnityEngine.Color, duration:number): @static
---@overload fun(target:UnityEngine.UI.Outline, endValue:UnityEngine.Color, duration:number): @static
---@overload fun(target:UnityEngine.UI.Text, endValue:UnityEngine.Color, duration:number): @static
---@static
---@param target UnityEngine.UI.Graphic
---@param endValue UnityEngine.Color
---@param duration number
---@return DG.Tweening.Tweener
function m.DOColor(target, endValue, duration) end

---@static
---@param target UnityEngine.UI.Image
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOFillAmount(target, endValue, duration) end

---@static
---@param target UnityEngine.UI.Image
---@param gradient UnityEngine.Gradient
---@param duration number
---@return DG.Tweening.Sequence
function m.DOGradientColor(target, gradient, duration) end

---@overload fun(target:UnityEngine.UI.LayoutElement, endValue:UnityEngine.Vector2, duration:number): @static
---@static
---@param target UnityEngine.UI.LayoutElement
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOFlexibleSize(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.UI.LayoutElement, endValue:UnityEngine.Vector2, duration:number): @static
---@static
---@param target UnityEngine.UI.LayoutElement
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMinSize(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.UI.LayoutElement, endValue:UnityEngine.Vector2, duration:number): @static
---@static
---@param target UnityEngine.UI.LayoutElement
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOPreferredSize(target, endValue, duration, snapping) end

---@static
---@param target UnityEngine.UI.Outline
---@param endValue UnityEngine.Vector2
---@param duration number
---@return DG.Tweening.Tweener
function m.DOScale(target, endValue, duration) end

---@overload fun(target:UnityEngine.RectTransform, endValue:UnityEngine.Vector2, duration:number): @static
---@static
---@param target UnityEngine.RectTransform
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPos(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.RectTransform, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.RectTransform
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPosX(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.RectTransform, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.RectTransform
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPosY(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.RectTransform, endValue:UnityEngine.Vector3, duration:number): @static
---@static
---@param target UnityEngine.RectTransform
---@param endValue UnityEngine.Vector3
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPos3D(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.RectTransform, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.RectTransform
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPos3DX(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.RectTransform, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.RectTransform
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPos3DY(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.RectTransform, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.RectTransform
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorPos3DZ(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.RectTransform, endValue:UnityEngine.Vector2, duration:number): @static
---@static
---@param target UnityEngine.RectTransform
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorMax(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.RectTransform, endValue:UnityEngine.Vector2, duration:number): @static
---@static
---@param target UnityEngine.RectTransform
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOAnchorMin(target, endValue, duration, snapping) end

---@static
---@param target UnityEngine.RectTransform
---@param endValue UnityEngine.Vector2
---@param duration number
---@return DG.Tweening.Tweener
function m.DOPivot(target, endValue, duration) end

---@static
---@param target UnityEngine.RectTransform
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOPivotX(target, endValue, duration) end

---@static
---@param target UnityEngine.RectTransform
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DOPivotY(target, endValue, duration) end

---@overload fun(target:UnityEngine.RectTransform, endValue:UnityEngine.Vector2, duration:number): @static
---@static
---@param target UnityEngine.RectTransform
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOSizeDelta(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.RectTransform, punch:UnityEngine.Vector2, duration:number, vibrato:number, elasticity:number): @static
---@overload fun(target:UnityEngine.RectTransform, punch:UnityEngine.Vector2, duration:number, vibrato:number): @static
---@overload fun(target:UnityEngine.RectTransform, punch:UnityEngine.Vector2, duration:number): @static
---@static
---@param target UnityEngine.RectTransform
---@param punch UnityEngine.Vector2
---@param duration number
---@param vibrato number
---@param elasticity number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOPunchAnchorPos(target, punch, duration, vibrato, elasticity, snapping) end

---@overload fun(target:UnityEngine.RectTransform, duration:number, strength:number, vibrato:number, randomness:number, snapping:boolean): @static
---@overload fun(target:UnityEngine.RectTransform, duration:number, strength:number, vibrato:number, randomness:number): @static
---@overload fun(target:UnityEngine.RectTransform, duration:number, strength:number, vibrato:number): @static
---@overload fun(target:UnityEngine.RectTransform, duration:number, strength:number): @static
---@overload fun(target:UnityEngine.RectTransform, duration:number): @static
---@overload fun(target:UnityEngine.RectTransform, duration:number, strength:UnityEngine.Vector2, vibrato:number, randomness:number, snapping:boolean, fadeOut:boolean): @static
---@overload fun(target:UnityEngine.RectTransform, duration:number, strength:UnityEngine.Vector2, vibrato:number, randomness:number, snapping:boolean): @static
---@overload fun(target:UnityEngine.RectTransform, duration:number, strength:UnityEngine.Vector2, vibrato:number, randomness:number): @static
---@overload fun(target:UnityEngine.RectTransform, duration:number, strength:UnityEngine.Vector2, vibrato:number): @static
---@overload fun(target:UnityEngine.RectTransform, duration:number, strength:UnityEngine.Vector2): @static
---@static
---@param target UnityEngine.RectTransform
---@param duration number
---@param strength number
---@param vibrato number
---@param randomness number
---@param snapping boolean
---@param fadeOut boolean
---@return DG.Tweening.Tweener
function m.DOShakeAnchorPos(target, duration, strength, vibrato, randomness, snapping, fadeOut) end

---@overload fun(target:UnityEngine.RectTransform, endValue:UnityEngine.Vector2, jumpPower:number, numJumps:number, duration:number): @static
---@static
---@param target UnityEngine.RectTransform
---@param endValue UnityEngine.Vector2
---@param jumpPower number
---@param numJumps number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Sequence
function m.DOJumpAnchorPos(target, endValue, jumpPower, numJumps, duration, snapping) end

---@overload fun(target:UnityEngine.UI.ScrollRect, endValue:UnityEngine.Vector2, duration:number): @static
---@static
---@param target UnityEngine.UI.ScrollRect
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DONormalizedPos(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.UI.ScrollRect, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.UI.ScrollRect
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOHorizontalNormalizedPos(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.UI.ScrollRect, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.UI.ScrollRect
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOVerticalNormalizedPos(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.UI.Slider, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.UI.Slider
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOValue(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.UI.Text, endValue:string, duration:number, richTextEnabled:boolean, scrambleMode:DG.Tweening.ScrambleMode): @static
---@overload fun(target:UnityEngine.UI.Text, endValue:string, duration:number, richTextEnabled:boolean): @static
---@overload fun(target:UnityEngine.UI.Text, endValue:string, duration:number): @static
---@static
---@param target UnityEngine.UI.Text
---@param endValue string
---@param duration number
---@param richTextEnabled boolean
---@param scrambleMode DG.Tweening.ScrambleMode
---@param scrambleChars string
---@return DG.Tweening.Tweener
function m.DOText(target, endValue, duration, richTextEnabled, scrambleMode, scrambleChars) end

---@overload fun(target:UnityEngine.UI.Image, endValue:UnityEngine.Color, duration:number): @static
---@overload fun(target:UnityEngine.UI.Text, endValue:UnityEngine.Color, duration:number): @static
---@static
---@param target UnityEngine.UI.Graphic
---@param endValue UnityEngine.Color
---@param duration number
---@return DG.Tweening.Tweener
function m.DOBlendableColor(target, endValue, duration) end

DG.Tweening.DOTweenModuleUI = m
return m
