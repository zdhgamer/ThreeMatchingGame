---@class SocketCommand : ControllerCommand
local m = {}

---@virtual
---@param message IMessage
function m:Execute(message) end

SocketCommand = m
return m
