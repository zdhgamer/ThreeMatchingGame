---@class LuaFramework.LuaManager : Manager
local m = {}

function m:InitStart() end

---@param filename string
function m:DoFile(filename) end

---@overload fun(funcName:string):
---@param funcName string
---@param ... any|any[]
---@return any[]
function m:CallFunction(funcName, ...) end

function m:LuaGC() end

function m:Close() end

LuaFramework.LuaManager = m
return m
