---@class TestInt64 : UnityEngine.MonoBehaviour
local m = {}

TestInt64 = m
return m
