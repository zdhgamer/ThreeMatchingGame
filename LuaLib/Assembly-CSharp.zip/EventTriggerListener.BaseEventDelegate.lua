---@class EventTriggerListener.BaseEventDelegate : System.MulticastDelegate
local m = {}

---@virtual
---@param go UnityEngine.GameObject
---@param eventData UnityEngine.EventSystems.BaseEventData
function m:Invoke(go, eventData) end

---@virtual
---@param go UnityEngine.GameObject
---@param eventData UnityEngine.EventSystems.BaseEventData
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(go, eventData, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

EventTriggerListener.BaseEventDelegate = m
return m
