---@class TestABLoader._LoadBundles_c__Iterator2 : System.Object
local m = {}

---@virtual
---@return boolean
function m:MoveNext() end

---@virtual
function m:Dispose() end

---@virtual
function m:Reset() end

TestABLoader._LoadBundles_c__Iterator2 = m
return m
