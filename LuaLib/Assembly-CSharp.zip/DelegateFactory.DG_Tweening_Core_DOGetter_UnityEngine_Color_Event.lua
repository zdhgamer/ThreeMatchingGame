---@class DelegateFactory.DG_Tweening_Core_DOGetter_UnityEngine_Color_Event : LuaInterface.LuaDelegate
local m = {}

---@return UnityEngine.Color
function m:Call() end

---@return UnityEngine.Color
function m:CallWithSelf() end

DelegateFactory.DG_Tweening_Core_DOGetter_UnityEngine_Color_Event = m
return m
