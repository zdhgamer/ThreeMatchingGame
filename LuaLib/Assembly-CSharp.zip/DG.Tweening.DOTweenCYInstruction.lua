---@class DG.Tweening.DOTweenCYInstruction : System.Object
local m = {}

DG.Tweening.DOTweenCYInstruction = m
return m
