---@class Facade : System.Object
local m = {}

---@virtual
---@param commandName string
---@param commandType System.Type
function m:RegisterCommand(commandName, commandType) end

---@virtual
---@param commandName string
function m:RemoveCommand(commandName) end

---@virtual
---@param commandName string
---@return boolean
function m:HasCommand(commandName) end

---@overload fun(commandType:System.Type)
---@param commandType System.Type
---@param ... string|string[]
function m:RegisterMultiCommand(commandType, ...) end

---@overload fun()
---@param ... string|string[]
function m:RemoveMultiCommand(...) end

---@overload fun(message:string)
---@param message string
---@param body any
function m:SendMessageCommand(message, body) end

---@overload fun(typeName:string):
---@param typeName string
---@param obj any
function m:AddManager(typeName, obj) end

---@param typeName string
---@return any
function m:GetManager(typeName) end

---@param typeName string
function m:RemoveManager(typeName) end

Facade = m
return m
