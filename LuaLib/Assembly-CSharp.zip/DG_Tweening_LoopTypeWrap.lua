---@class DG_Tweening_LoopTypeWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

DG_Tweening_LoopTypeWrap = m
return m
