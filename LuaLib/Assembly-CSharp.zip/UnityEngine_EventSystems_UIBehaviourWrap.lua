---@class UnityEngine_EventSystems_UIBehaviourWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

UnityEngine_EventSystems_UIBehaviourWrap = m
return m
