---@class ScriptsFromFile : UnityEngine.MonoBehaviour
local m = {}

ScriptsFromFile = m
return m
