---@class DelegateFactory.UnityEngine_AudioClip_PCMSetPositionCallback_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 number
function m:Call(param0) end

---@param param0 number
function m:CallWithSelf(param0) end

DelegateFactory.UnityEngine_AudioClip_PCMSetPositionCallback_Event = m
return m
