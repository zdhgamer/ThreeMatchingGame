---@class DG.Tweening.DOTweenModuleUI._DOAnchorPos3DX_c__AnonStorey10 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOAnchorPos3DX_c__AnonStorey10 = m
return m
