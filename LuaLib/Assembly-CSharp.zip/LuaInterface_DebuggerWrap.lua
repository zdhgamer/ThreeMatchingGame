---@class LuaInterface_DebuggerWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaInterface_DebuggerWrap = m
return m
