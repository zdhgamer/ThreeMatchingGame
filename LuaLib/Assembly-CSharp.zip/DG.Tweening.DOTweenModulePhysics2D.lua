---@class DG.Tweening.DOTweenModulePhysics2D : System.Object
local m = {}

---@overload fun(target:UnityEngine.Rigidbody2D, endValue:UnityEngine.Vector2, duration:number): @static
---@static
---@param target UnityEngine.Rigidbody2D
---@param endValue UnityEngine.Vector2
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMove(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Rigidbody2D, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.Rigidbody2D
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMoveX(target, endValue, duration, snapping) end

---@overload fun(target:UnityEngine.Rigidbody2D, endValue:number, duration:number): @static
---@static
---@param target UnityEngine.Rigidbody2D
---@param endValue number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Tweener
function m.DOMoveY(target, endValue, duration, snapping) end

---@static
---@param target UnityEngine.Rigidbody2D
---@param endValue number
---@param duration number
---@return DG.Tweening.Tweener
function m.DORotate(target, endValue, duration) end

---@overload fun(target:UnityEngine.Rigidbody2D, endValue:UnityEngine.Vector2, jumpPower:number, numJumps:number, duration:number): @static
---@static
---@param target UnityEngine.Rigidbody2D
---@param endValue UnityEngine.Vector2
---@param jumpPower number
---@param numJumps number
---@param duration number
---@param snapping boolean
---@return DG.Tweening.Sequence
function m.DOJump(target, endValue, jumpPower, numJumps, duration, snapping) end

DG.Tweening.DOTweenModulePhysics2D = m
return m
