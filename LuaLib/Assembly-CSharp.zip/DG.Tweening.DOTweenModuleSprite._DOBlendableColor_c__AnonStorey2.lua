---@class DG.Tweening.DOTweenModuleSprite._DOBlendableColor_c__AnonStorey2 : System.Object
local m = {}

DG.Tweening.DOTweenModuleSprite._DOBlendableColor_c__AnonStorey2 = m
return m
