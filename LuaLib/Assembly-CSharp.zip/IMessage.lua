---@class IMessage : table
---@field public Name string
---@field public Body any
---@field public Type string
local m = {}

---@abstract
---@return string
function m:ToString() end

IMessage = m
return m
