---@class DG.Tweening.DOTweenModulePhysics._DOMoveY_c__AnonStorey2 : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics._DOMoveY_c__AnonStorey2 = m
return m
