---@class DG.Tweening.DOTweenModuleUI._DOVerticalNormalizedPos_c__AnonStorey1F : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOVerticalNormalizedPos_c__AnonStorey1F = m
return m
