---@class Base : UnityEngine.MonoBehaviour
local m = {}

Base = m
return m
