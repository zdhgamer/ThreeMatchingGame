---@class AppFacade : Facade
---@field public Instance AppFacade @static
local m = {}

function m:StartUp() end

AppFacade = m
return m
