---@class DG.Tweening
DG.Tweening = {}