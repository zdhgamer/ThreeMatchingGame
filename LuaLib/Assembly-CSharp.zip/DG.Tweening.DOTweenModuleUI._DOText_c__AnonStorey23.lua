---@class DG.Tweening.DOTweenModuleUI._DOText_c__AnonStorey23 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOText_c__AnonStorey23 = m
return m
