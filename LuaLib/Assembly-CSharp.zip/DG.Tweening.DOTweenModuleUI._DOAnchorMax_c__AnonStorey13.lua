---@class DG.Tweening.DOTweenModuleUI._DOAnchorMax_c__AnonStorey13 : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOAnchorMax_c__AnonStorey13 = m
return m
