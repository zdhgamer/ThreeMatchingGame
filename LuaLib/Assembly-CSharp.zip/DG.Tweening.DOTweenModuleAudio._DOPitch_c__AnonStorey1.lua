---@class DG.Tweening.DOTweenModuleAudio._DOPitch_c__AnonStorey1 : System.Object
local m = {}

DG.Tweening.DOTweenModuleAudio._DOPitch_c__AnonStorey1 = m
return m
