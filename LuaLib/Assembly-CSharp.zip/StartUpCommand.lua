---@class StartUpCommand : ControllerCommand
local m = {}

---@virtual
---@param message IMessage
function m:Execute(message) end

StartUpCommand = m
return m
