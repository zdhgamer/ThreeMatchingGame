---@class DG.Tweening.DOTweenModulePhysics2D._DOJump_c__AnonStorey4 : System.Object
local m = {}

DG.Tweening.DOTweenModulePhysics2D._DOJump_c__AnonStorey4 = m
return m
