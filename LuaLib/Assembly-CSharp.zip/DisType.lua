---@class DisType : System.Enum
---@field public Exception DisType @static
---@field public Disconnect DisType @static
---@field public value__ number
local m = {}

DisType = m
return m
