---@class DG.Tweening.DOTweenModuleUI._DOAnchorPosY_c__AnonStoreyE : System.Object
local m = {}

DG.Tweening.DOTweenModuleUI._DOAnchorPosY_c__AnonStoreyE = m
return m
