---@class LuaConst : System.Object
---@field public luaDir string @static
---@field public toluaDir string @static
---@field public osDir string @static
---@field public luaResDir string @static
---@field public zbsDir string @static
---@field public openLuaSocket boolean @static
---@field public openLuaDebugger boolean @static
local m = {}

LuaConst = m
return m
