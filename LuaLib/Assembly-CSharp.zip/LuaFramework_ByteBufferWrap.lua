---@class LuaFramework_ByteBufferWrap : System.Object
local m = {}

---@static
---@param L LuaInterface.LuaState
function m.Register(L) end

LuaFramework_ByteBufferWrap = m
return m
