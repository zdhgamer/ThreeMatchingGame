---@class DelegateFactory.EventTriggerListener_AxisEventDelegate_Event : LuaInterface.LuaDelegate
local m = {}

---@param param0 UnityEngine.GameObject
---@param param1 UnityEngine.EventSystems.AxisEventData
function m:Call(param0, param1) end

---@param param0 UnityEngine.GameObject
---@param param1 UnityEngine.EventSystems.AxisEventData
function m:CallWithSelf(param0, param1) end

DelegateFactory.EventTriggerListener_AxisEventDelegate_Event = m
return m
