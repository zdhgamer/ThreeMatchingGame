---@class Controller : System.Object
---@field public Instance IController @static
local m = {}

---@virtual
---@param note IMessage
function m:ExecuteCommand(note) end

---@virtual
---@param commandName string
---@param commandType System.Type
function m:RegisterCommand(commandName, commandType) end

---@virtual
---@param view IView
---@param commandNames string[]
function m:RegisterViewCommand(view, commandNames) end

---@virtual
---@param commandName string
---@return boolean
function m:HasCommand(commandName) end

---@virtual
---@param commandName string
function m:RemoveCommand(commandName) end

---@virtual
---@param view IView
---@param commandNames string[]
function m:RemoveViewCommand(view, commandNames) end

Controller = m
return m
