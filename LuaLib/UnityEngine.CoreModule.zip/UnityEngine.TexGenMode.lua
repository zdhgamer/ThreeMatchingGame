---@class UnityEngine.TexGenMode : System.Enum
---@field public None UnityEngine.TexGenMode @static
---@field public SphereMap UnityEngine.TexGenMode @static
---@field public Object UnityEngine.TexGenMode @static
---@field public EyeLinear UnityEngine.TexGenMode @static
---@field public CubeReflect UnityEngine.TexGenMode @static
---@field public CubeNormal UnityEngine.TexGenMode @static
---@field public value__ number
local m = {}

UnityEngine.TexGenMode = m
return m
