---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate.DirectorUpdateAnimationEnd : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate.DirectorUpdateAnimationEnd = m
return m
