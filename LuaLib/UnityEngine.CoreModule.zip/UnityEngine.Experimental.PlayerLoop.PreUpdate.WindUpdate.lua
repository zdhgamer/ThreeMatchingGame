---@class UnityEngine.Experimental.PlayerLoop.PreUpdate.WindUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreUpdate.WindUpdate = m
return m
