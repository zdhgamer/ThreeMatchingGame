---@class UnityEngine.SleepTimeout : System.Object
---@field public NeverSleep number @static
---@field public SystemSetting number @static
local m = {}

UnityEngine.SleepTimeout = m
return m
