---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.XRUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.XRUpdate = m
return m
