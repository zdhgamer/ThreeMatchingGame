---@class UnityEngine.Experimental.PlayerLoop.Initialization.XREarlyUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.Initialization.XREarlyUpdate = m
return m
