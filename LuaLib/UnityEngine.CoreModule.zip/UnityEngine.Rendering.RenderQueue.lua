---@class UnityEngine.Rendering.RenderQueue : System.Enum
---@field public Background UnityEngine.Rendering.RenderQueue @static
---@field public Geometry UnityEngine.Rendering.RenderQueue @static
---@field public AlphaTest UnityEngine.Rendering.RenderQueue @static
---@field public GeometryLast UnityEngine.Rendering.RenderQueue @static
---@field public Transparent UnityEngine.Rendering.RenderQueue @static
---@field public Overlay UnityEngine.Rendering.RenderQueue @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.RenderQueue = m
return m
