---@class UnityEngine.Rendering.AmbientMode : System.Enum
---@field public Skybox UnityEngine.Rendering.AmbientMode @static
---@field public Trilight UnityEngine.Rendering.AmbientMode @static
---@field public Flat UnityEngine.Rendering.AmbientMode @static
---@field public Custom UnityEngine.Rendering.AmbientMode @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.AmbientMode = m
return m
