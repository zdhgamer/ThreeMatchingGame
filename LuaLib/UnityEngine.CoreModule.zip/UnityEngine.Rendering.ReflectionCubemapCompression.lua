---@class UnityEngine.Rendering.ReflectionCubemapCompression : System.Enum
---@field public Uncompressed UnityEngine.Rendering.ReflectionCubemapCompression @static
---@field public Compressed UnityEngine.Rendering.ReflectionCubemapCompression @static
---@field public Auto UnityEngine.Rendering.ReflectionCubemapCompression @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ReflectionCubemapCompression = m
return m
