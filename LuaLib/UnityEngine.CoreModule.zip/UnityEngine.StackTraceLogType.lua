---@class UnityEngine.StackTraceLogType : System.Enum
---@field public None UnityEngine.StackTraceLogType @static
---@field public ScriptOnly UnityEngine.StackTraceLogType @static
---@field public Full UnityEngine.StackTraceLogType @static
---@field public value__ number
local m = {}

UnityEngine.StackTraceLogType = m
return m
