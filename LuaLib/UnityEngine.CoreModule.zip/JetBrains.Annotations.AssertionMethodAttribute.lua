---@class JetBrains.Annotations.AssertionMethodAttribute : System.Attribute
local m = {}

JetBrains.Annotations.AssertionMethodAttribute = m
return m
