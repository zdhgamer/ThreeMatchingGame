---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.EnlightenRuntimeUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.EnlightenRuntimeUpdate = m
return m
