---@class UnityEngine.CursorLockMode : System.Enum
---@field public None UnityEngine.CursorLockMode @static
---@field public Locked UnityEngine.CursorLockMode @static
---@field public Confined UnityEngine.CursorLockMode @static
---@field public value__ number
local m = {}

UnityEngine.CursorLockMode = m
return m
