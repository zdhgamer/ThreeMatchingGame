---@class UnityEngine.Rendering.GPUFence : System.ValueType
---@field public passed boolean
local m = {}

UnityEngine.Rendering.GPUFence = m
return m
