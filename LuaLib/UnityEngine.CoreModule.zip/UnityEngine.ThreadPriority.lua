---@class UnityEngine.ThreadPriority : System.Enum
---@field public Low UnityEngine.ThreadPriority @static
---@field public BelowNormal UnityEngine.ThreadPriority @static
---@field public Normal UnityEngine.ThreadPriority @static
---@field public High UnityEngine.ThreadPriority @static
---@field public value__ number
local m = {}

UnityEngine.ThreadPriority = m
return m
