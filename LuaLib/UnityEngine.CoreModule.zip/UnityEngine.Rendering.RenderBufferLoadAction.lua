---@class UnityEngine.Rendering.RenderBufferLoadAction : System.Enum
---@field public Load UnityEngine.Rendering.RenderBufferLoadAction @static
---@field public Clear UnityEngine.Rendering.RenderBufferLoadAction @static
---@field public DontCare UnityEngine.Rendering.RenderBufferLoadAction @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.RenderBufferLoadAction = m
return m
