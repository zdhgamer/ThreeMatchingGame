---@class UnityEngine.TextureWrapMode : System.Enum
---@field public Repeat UnityEngine.TextureWrapMode @static
---@field public Clamp UnityEngine.TextureWrapMode @static
---@field public Mirror UnityEngine.TextureWrapMode @static
---@field public MirrorOnce UnityEngine.TextureWrapMode @static
---@field public value__ number
local m = {}

UnityEngine.TextureWrapMode = m
return m
