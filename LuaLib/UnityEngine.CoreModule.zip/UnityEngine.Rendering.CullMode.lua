---@class UnityEngine.Rendering.CullMode : System.Enum
---@field public Off UnityEngine.Rendering.CullMode @static
---@field public Front UnityEngine.Rendering.CullMode @static
---@field public Back UnityEngine.Rendering.CullMode @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.CullMode = m
return m
