---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateKinect : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UpdateKinect = m
return m
