---@class UnityEngine.LightmapData : System.Object
---@field public lightmapLight UnityEngine.Texture2D
---@field public lightmapColor UnityEngine.Texture2D
---@field public lightmapDir UnityEngine.Texture2D
---@field public shadowMask UnityEngine.Texture2D
---@field public lightmap UnityEngine.Texture2D
---@field public lightmapFar UnityEngine.Texture2D
---@field public lightmapNear UnityEngine.Texture2D
local m = {}

UnityEngine.LightmapData = m
return m
