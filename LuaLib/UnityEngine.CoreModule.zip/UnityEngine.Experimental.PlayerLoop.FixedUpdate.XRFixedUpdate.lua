---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate.XRFixedUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate.XRFixedUpdate = m
return m
