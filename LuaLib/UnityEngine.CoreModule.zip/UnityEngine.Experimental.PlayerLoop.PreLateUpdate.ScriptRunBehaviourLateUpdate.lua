---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate.ScriptRunBehaviourLateUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate.ScriptRunBehaviourLateUpdate = m
return m
