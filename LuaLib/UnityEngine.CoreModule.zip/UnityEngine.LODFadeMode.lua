---@class UnityEngine.LODFadeMode : System.Enum
---@field public None UnityEngine.LODFadeMode @static
---@field public CrossFade UnityEngine.LODFadeMode @static
---@field public SpeedTree UnityEngine.LODFadeMode @static
---@field public value__ number
local m = {}

UnityEngine.LODFadeMode = m
return m
