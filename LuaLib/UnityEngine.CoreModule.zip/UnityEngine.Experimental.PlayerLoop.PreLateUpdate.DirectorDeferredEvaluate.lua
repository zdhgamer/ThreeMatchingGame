---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate.DirectorDeferredEvaluate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate.DirectorDeferredEvaluate = m
return m
