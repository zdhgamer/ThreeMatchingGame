---@class UnityEngine.LowerResBlitTexture : UnityEngine.Object
local m = {}

UnityEngine.LowerResBlitTexture = m
return m
