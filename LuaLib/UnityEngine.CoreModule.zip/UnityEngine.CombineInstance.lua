---@class UnityEngine.CombineInstance : System.ValueType
---@field public mesh UnityEngine.Mesh
---@field public subMeshIndex number
---@field public transform UnityEngine.Matrix4x4
---@field public lightmapScaleOffset UnityEngine.Vector4
---@field public realtimeLightmapScaleOffset UnityEngine.Vector4
local m = {}

UnityEngine.CombineInstance = m
return m
