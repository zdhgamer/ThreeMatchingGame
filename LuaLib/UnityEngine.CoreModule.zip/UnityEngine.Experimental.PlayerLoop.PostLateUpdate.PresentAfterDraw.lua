---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PresentAfterDraw : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PresentAfterDraw = m
return m
