---@class UnityEngine.TransparencySortMode : System.Enum
---@field public Default UnityEngine.TransparencySortMode @static
---@field public Perspective UnityEngine.TransparencySortMode @static
---@field public Orthographic UnityEngine.TransparencySortMode @static
---@field public CustomAxis UnityEngine.TransparencySortMode @static
---@field public value__ number
local m = {}

UnityEngine.TransparencySortMode = m
return m
