---@class UnityEngine.NPOTSupport : System.Enum
---@field public None UnityEngine.NPOTSupport @static
---@field public Restricted UnityEngine.NPOTSupport @static
---@field public Full UnityEngine.NPOTSupport @static
---@field public value__ number
local m = {}

UnityEngine.NPOTSupport = m
return m
