---@class JetBrains.Annotations.CanBeNullAttribute : System.Attribute
local m = {}

JetBrains.Annotations.CanBeNullAttribute = m
return m
