---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UnityWebRequestUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.UnityWebRequestUpdate = m
return m
