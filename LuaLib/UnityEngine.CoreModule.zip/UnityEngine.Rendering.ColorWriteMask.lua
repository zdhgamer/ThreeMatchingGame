---@class UnityEngine.Rendering.ColorWriteMask : System.Enum
---@field public Alpha UnityEngine.Rendering.ColorWriteMask @static
---@field public Blue UnityEngine.Rendering.ColorWriteMask @static
---@field public Green UnityEngine.Rendering.ColorWriteMask @static
---@field public Red UnityEngine.Rendering.ColorWriteMask @static
---@field public All UnityEngine.Rendering.ColorWriteMask @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ColorWriteMask = m
return m
