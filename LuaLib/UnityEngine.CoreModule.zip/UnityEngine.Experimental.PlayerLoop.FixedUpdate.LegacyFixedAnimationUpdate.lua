---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate.LegacyFixedAnimationUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate.LegacyFixedAnimationUpdate = m
return m
