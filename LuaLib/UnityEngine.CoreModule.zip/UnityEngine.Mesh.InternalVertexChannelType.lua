---@class UnityEngine.Mesh.InternalVertexChannelType : System.Enum
---@field public Float UnityEngine.Mesh.InternalVertexChannelType @static
---@field public Color UnityEngine.Mesh.InternalVertexChannelType @static
---@field public value__ number
local m = {}

UnityEngine.Mesh.InternalVertexChannelType = m
return m
