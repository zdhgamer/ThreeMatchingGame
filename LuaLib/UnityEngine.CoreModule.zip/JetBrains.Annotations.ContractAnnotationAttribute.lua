---@class JetBrains.Annotations.ContractAnnotationAttribute : System.Attribute
---@field public Contract string
---@field public ForceFullStates boolean
local m = {}

JetBrains.Annotations.ContractAnnotationAttribute = m
return m
