---@class UnityEngine.Rendering.BuiltinRenderTextureType : System.Enum
---@field public PropertyName UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public BufferPtr UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public RenderTexture UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public BindableTexture UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public None UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public CurrentActive UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public CameraTarget UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public Depth UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public DepthNormals UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public ResolvedDepth UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public PrepassNormalsSpec UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public PrepassLight UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public PrepassLightSpec UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public GBuffer0 UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public GBuffer1 UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public GBuffer2 UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public GBuffer3 UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public Reflections UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public MotionVectors UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public GBuffer4 UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public GBuffer5 UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public GBuffer6 UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public GBuffer7 UnityEngine.Rendering.BuiltinRenderTextureType @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.BuiltinRenderTextureType = m
return m
