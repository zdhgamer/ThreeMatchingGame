---@class UnityEngine.Experimental.PlayerLoop.EarlyUpdate.TangoUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.EarlyUpdate.TangoUpdate = m
return m
