---@class UnityEngine.Experimental.PlayerLoop.Update.ScriptRunBehaviourUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.Update.ScriptRunBehaviourUpdate = m
return m
