---@class UnityEngine.Rendering.BlendMode : System.Enum
---@field public Zero UnityEngine.Rendering.BlendMode @static
---@field public One UnityEngine.Rendering.BlendMode @static
---@field public DstColor UnityEngine.Rendering.BlendMode @static
---@field public SrcColor UnityEngine.Rendering.BlendMode @static
---@field public OneMinusDstColor UnityEngine.Rendering.BlendMode @static
---@field public SrcAlpha UnityEngine.Rendering.BlendMode @static
---@field public OneMinusSrcColor UnityEngine.Rendering.BlendMode @static
---@field public DstAlpha UnityEngine.Rendering.BlendMode @static
---@field public OneMinusDstAlpha UnityEngine.Rendering.BlendMode @static
---@field public SrcAlphaSaturate UnityEngine.Rendering.BlendMode @static
---@field public OneMinusSrcAlpha UnityEngine.Rendering.BlendMode @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.BlendMode = m
return m
