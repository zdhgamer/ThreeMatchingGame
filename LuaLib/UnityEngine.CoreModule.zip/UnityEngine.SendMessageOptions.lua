---@class UnityEngine.SendMessageOptions : System.Enum
---@field public RequireReceiver UnityEngine.SendMessageOptions @static
---@field public DontRequireReceiver UnityEngine.SendMessageOptions @static
---@field public value__ number
local m = {}

UnityEngine.SendMessageOptions = m
return m
