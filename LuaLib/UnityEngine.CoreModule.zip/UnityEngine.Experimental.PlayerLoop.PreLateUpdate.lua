---@class UnityEngine.Experimental.PlayerLoop.PreLateUpdate : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PreLateUpdate = m
return m
