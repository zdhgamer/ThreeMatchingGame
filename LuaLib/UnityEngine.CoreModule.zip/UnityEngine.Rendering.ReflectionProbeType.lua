---@class UnityEngine.Rendering.ReflectionProbeType : System.Enum
---@field public Cube UnityEngine.Rendering.ReflectionProbeType @static
---@field public Card UnityEngine.Rendering.ReflectionProbeType @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ReflectionProbeType = m
return m
