---@class UnityEngine.TouchType : System.Enum
---@field public Direct UnityEngine.TouchType @static
---@field public Indirect UnityEngine.TouchType @static
---@field public Stylus UnityEngine.TouchType @static
---@field public value__ number
local m = {}

UnityEngine.TouchType = m
return m
