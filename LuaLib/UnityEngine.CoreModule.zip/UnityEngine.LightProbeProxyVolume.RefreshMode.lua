---@class UnityEngine.LightProbeProxyVolume.RefreshMode : System.Enum
---@field public Automatic UnityEngine.LightProbeProxyVolume.RefreshMode @static
---@field public EveryFrame UnityEngine.LightProbeProxyVolume.RefreshMode @static
---@field public ViaScripting UnityEngine.LightProbeProxyVolume.RefreshMode @static
---@field public value__ number
local m = {}

UnityEngine.LightProbeProxyVolume.RefreshMode = m
return m
