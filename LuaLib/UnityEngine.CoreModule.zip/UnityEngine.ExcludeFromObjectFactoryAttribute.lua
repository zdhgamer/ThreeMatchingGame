---@class UnityEngine.ExcludeFromObjectFactoryAttribute : System.Attribute
local m = {}

UnityEngine.ExcludeFromObjectFactoryAttribute = m
return m
