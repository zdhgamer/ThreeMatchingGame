---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PlayerUpdateCanvases : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.PlayerUpdateCanvases = m
return m
