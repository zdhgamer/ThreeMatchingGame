---@class UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateCanvasRectTransform : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.PostLateUpdate.UpdateCanvasRectTransform = m
return m
