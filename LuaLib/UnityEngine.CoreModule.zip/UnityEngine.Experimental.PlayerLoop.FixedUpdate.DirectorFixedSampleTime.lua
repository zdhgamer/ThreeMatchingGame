---@class UnityEngine.Experimental.PlayerLoop.FixedUpdate.DirectorFixedSampleTime : System.ValueType
local m = {}

UnityEngine.Experimental.PlayerLoop.FixedUpdate.DirectorFixedSampleTime = m
return m
