---@class UnityEngine.Experimental.Rendering.DrawRendererSettings._shaderPassNames___FixedBuffer0 : System.ValueType
---@field public FixedElementField number
local m = {}

UnityEngine.Experimental.Rendering.DrawRendererSettings._shaderPassNames___FixedBuffer0 = m
return m
