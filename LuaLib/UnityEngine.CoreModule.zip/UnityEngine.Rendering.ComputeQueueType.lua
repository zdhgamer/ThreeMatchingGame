---@class UnityEngine.Rendering.ComputeQueueType : System.Enum
---@field public Default UnityEngine.Rendering.ComputeQueueType @static
---@field public Background UnityEngine.Rendering.ComputeQueueType @static
---@field public Urgent UnityEngine.Rendering.ComputeQueueType @static
---@field public value__ number
local m = {}

UnityEngine.Rendering.ComputeQueueType = m
return m
