---@class UnityEngine.AndroidJavaException : System.Exception
---@field public StackTrace string
local m = {}

UnityEngine.AndroidJavaException = m
return m
