---@class System.Diagnostics.DebuggerNonUserCodeAttribute : System.Attribute
local m = {}

System.Diagnostics.DebuggerNonUserCodeAttribute = m
return m
