---@class System.Array.Swapper : System.MulticastDelegate
local m = {}

---@virtual
---@param i number
---@param j number
function m:Invoke(i, j) end

---@virtual
---@param i number
---@param j number
---@param callback fun(ar:System.IAsyncResult)
---@param object any
---@return System.IAsyncResult
function m:BeginInvoke(i, j, callback, object) end

---@virtual
---@param result System.IAsyncResult
function m:EndInvoke(result) end

System.Array.Swapper = m
return m
