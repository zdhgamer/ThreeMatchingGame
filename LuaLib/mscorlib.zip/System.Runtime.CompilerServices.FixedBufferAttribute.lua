---@class System.Runtime.CompilerServices.FixedBufferAttribute : System.Attribute
---@field public ElementType System.Type
---@field public Length number
local m = {}

System.Runtime.CompilerServices.FixedBufferAttribute = m
return m
