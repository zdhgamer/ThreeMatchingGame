---@class System.FormatException : System.SystemException
local m = {}

System.FormatException = m
return m
