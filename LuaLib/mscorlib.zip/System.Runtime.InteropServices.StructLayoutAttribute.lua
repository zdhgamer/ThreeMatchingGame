---@class System.Runtime.InteropServices.StructLayoutAttribute : System.Attribute
---@field public CharSet System.Runtime.InteropServices.CharSet
---@field public Pack number
---@field public Size number
---@field public Value System.Runtime.InteropServices.LayoutKind
local m = {}

System.Runtime.InteropServices.StructLayoutAttribute = m
return m
