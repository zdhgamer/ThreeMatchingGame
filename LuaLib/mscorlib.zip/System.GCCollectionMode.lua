---@class System.GCCollectionMode : System.Enum
---@field public Default System.GCCollectionMode @static
---@field public Forced System.GCCollectionMode @static
---@field public Optimized System.GCCollectionMode @static
---@field public value__ number
local m = {}

System.GCCollectionMode = m
return m
