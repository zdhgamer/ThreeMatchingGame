---@class Mono.Globalization.Unicode.NormalizationCheck : System.Enum
---@field public Yes Mono.Globalization.Unicode.NormalizationCheck @static
---@field public No Mono.Globalization.Unicode.NormalizationCheck @static
---@field public Maybe Mono.Globalization.Unicode.NormalizationCheck @static
---@field public value__ number
local m = {}

Mono.Globalization.Unicode.NormalizationCheck = m
return m
