---@class System.StringSplitOptions : System.Enum
---@field public None System.StringSplitOptions @static
---@field public RemoveEmptyEntries System.StringSplitOptions @static
---@field public value__ number
local m = {}

System.StringSplitOptions = m
return m
