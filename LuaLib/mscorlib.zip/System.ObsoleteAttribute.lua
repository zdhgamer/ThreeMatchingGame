---@class System.ObsoleteAttribute : System.Attribute
---@field public Message string
---@field public IsError boolean
local m = {}

System.ObsoleteAttribute = m
return m
