---@class System.Runtime.CompilerServices.InternalsVisibleToAttribute : System.Attribute
---@field public AssemblyName string
---@field public AllInternalsVisible boolean
local m = {}

System.Runtime.CompilerServices.InternalsVisibleToAttribute = m
return m
