---@class Mono.Interop.IDispatch : table
local m = {}

Mono.Interop.IDispatch = m
return m
