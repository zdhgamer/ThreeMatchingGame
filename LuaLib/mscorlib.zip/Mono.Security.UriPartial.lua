---@class Mono.Security.UriPartial : System.Enum
---@field public Scheme Mono.Security.UriPartial @static
---@field public Authority Mono.Security.UriPartial @static
---@field public Path Mono.Security.UriPartial @static
---@field public value__ number
local m = {}

Mono.Security.UriPartial = m
return m
