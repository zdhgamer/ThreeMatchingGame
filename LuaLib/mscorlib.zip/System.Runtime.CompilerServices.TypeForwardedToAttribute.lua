---@class System.Runtime.CompilerServices.TypeForwardedToAttribute : System.Attribute
---@field public Destination System.Type
local m = {}

System.Runtime.CompilerServices.TypeForwardedToAttribute = m
return m
