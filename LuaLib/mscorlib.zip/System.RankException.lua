---@class System.RankException : System.SystemException
local m = {}

System.RankException = m
return m
