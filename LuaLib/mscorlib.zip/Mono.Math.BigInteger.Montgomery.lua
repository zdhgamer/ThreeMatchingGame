---@class Mono.Math.BigInteger.Montgomery : System.Object
local m = {}

---@static
---@param n number
---@return number
function m.Inverse(n) end

---@static
---@param n Mono.Math.BigInteger
---@param m Mono.Math.BigInteger
---@return Mono.Math.BigInteger
function m.ToMont(n, m) end

---@static
---@param n Mono.Math.BigInteger
---@param m Mono.Math.BigInteger
---@param mPrime number
---@return Mono.Math.BigInteger
function m.Reduce(n, m, mPrime) end

Mono.Math.BigInteger.Montgomery = m
return m
