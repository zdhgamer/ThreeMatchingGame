---@class System.Object : table
local m = {}

---@overload fun(objA:any, objB:any): @static
---@virtual
---@param obj any
---@return boolean
function m:Equals(obj) end

---@virtual
---@return number
function m:GetHashCode() end

---@return System.Type
function m:GetType() end

---@virtual
---@return string
function m:ToString() end

---@static
---@param objA any
---@param objB any
---@return boolean
function m.ReferenceEquals(objA, objB) end

System.Object = m
return m
