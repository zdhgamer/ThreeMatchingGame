---@class System.Diagnostics.SymbolStore.SymDocumentType : System.Object
---@field public Text System.Guid @static
local m = {}

System.Diagnostics.SymbolStore.SymDocumentType = m
return m
