---@class System.ConsoleSpecialKey : System.Enum
---@field public ControlC System.ConsoleSpecialKey @static
---@field public ControlBreak System.ConsoleSpecialKey @static
---@field public value__ number
local m = {}

System.ConsoleSpecialKey = m
return m
