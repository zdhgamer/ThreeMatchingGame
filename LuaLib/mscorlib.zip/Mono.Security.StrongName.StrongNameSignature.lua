---@class Mono.Security.StrongName.StrongNameSignature : System.Object
---@field public Hash string
---@field public Signature string
---@field public MetadataPosition number
---@field public MetadataLength number
---@field public SignaturePosition number
---@field public SignatureLength number
---@field public CliFlag number
---@field public CliFlagPosition number
local m = {}

Mono.Security.StrongName.StrongNameSignature = m
return m
