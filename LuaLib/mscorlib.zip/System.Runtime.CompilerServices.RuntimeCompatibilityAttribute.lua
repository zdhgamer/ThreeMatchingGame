---@class System.Runtime.CompilerServices.RuntimeCompatibilityAttribute : System.Attribute
---@field public WrapNonExceptionThrows boolean
local m = {}

System.Runtime.CompilerServices.RuntimeCompatibilityAttribute = m
return m
