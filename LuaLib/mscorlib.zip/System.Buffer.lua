---@class System.Buffer : System.Object
local m = {}

---@static
---@param array System.Array
---@return number
function m.ByteLength(array) end

---@static
---@param array System.Array
---@param index number
---@return number
function m.GetByte(array, index) end

---@static
---@param array System.Array
---@param index number
---@param value number
function m.SetByte(array, index, value) end

---@static
---@param src System.Array
---@param srcOffset number
---@param dst System.Array
---@param dstOffset number
---@param count number
function m.BlockCopy(src, srcOffset, dst, dstOffset, count) end

System.Buffer = m
return m
