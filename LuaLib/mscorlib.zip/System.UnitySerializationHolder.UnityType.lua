---@class System.UnitySerializationHolder.UnityType : System.Enum
---@field public DBNull System.UnitySerializationHolder.UnityType @static
---@field public Type System.UnitySerializationHolder.UnityType @static
---@field public Module System.UnitySerializationHolder.UnityType @static
---@field public Assembly System.UnitySerializationHolder.UnityType @static
---@field public value__ number
local m = {}

System.UnitySerializationHolder.UnityType = m
return m
