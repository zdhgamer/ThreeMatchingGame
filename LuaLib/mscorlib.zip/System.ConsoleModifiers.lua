---@class System.ConsoleModifiers : System.Enum
---@field public Alt System.ConsoleModifiers @static
---@field public Shift System.ConsoleModifiers @static
---@field public Control System.ConsoleModifiers @static
---@field public value__ number
local m = {}

System.ConsoleModifiers = m
return m
