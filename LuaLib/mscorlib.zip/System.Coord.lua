---@class System.Coord : System.ValueType
---@field public X number
---@field public Y number
local m = {}

System.Coord = m
return m
