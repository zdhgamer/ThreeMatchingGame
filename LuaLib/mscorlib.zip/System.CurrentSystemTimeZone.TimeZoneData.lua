---@class System.CurrentSystemTimeZone.TimeZoneData : System.Enum
---@field public DaylightSavingStartIdx System.CurrentSystemTimeZone.TimeZoneData @static
---@field public DaylightSavingEndIdx System.CurrentSystemTimeZone.TimeZoneData @static
---@field public UtcOffsetIdx System.CurrentSystemTimeZone.TimeZoneData @static
---@field public AdditionalDaylightOffsetIdx System.CurrentSystemTimeZone.TimeZoneData @static
---@field public value__ number
local m = {}

System.CurrentSystemTimeZone.TimeZoneData = m
return m
