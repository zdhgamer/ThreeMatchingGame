---@class System.Collections.ICollection : table
---@field public Count number
---@field public IsSynchronized boolean
---@field public SyncRoot any
local m = {}

---@abstract
---@param array System.Array
---@param index number
function m:CopyTo(array, index) end

System.Collections.ICollection = m
return m
